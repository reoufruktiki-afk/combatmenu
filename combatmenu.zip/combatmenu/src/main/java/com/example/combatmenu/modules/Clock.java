package com.example.combatmenu.modules;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class Clock {
    // Часы по умолчанию включены, чтобы время было видно сразу
    public static boolean enabled = true;

    // Формат времени HH:mm:ss
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("HH:mm:ss");

    // Возвращает текущее время в виде строки (вызывается каждый кадр)
    public static String getTime() {
        return LocalTime.now().format(FORMATTER);
    }
}
