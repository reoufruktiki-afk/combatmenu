package com.example.combatmenu.modules;

public class Velocity {
    // Состояние модуля (включён / выключен)
    public static boolean enabled = false;
}
