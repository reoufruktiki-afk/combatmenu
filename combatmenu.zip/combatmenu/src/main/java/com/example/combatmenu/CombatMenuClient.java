package com.example.combatmenu;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class CombatMenuClient implements ClientModInitializer {

    // Клавиша открытия меню
    private static KeyBinding openMenuKey;

    @Override
    public void onInitializeClient() {
        // Регистрация клавиши: Right Shift, категория берётся из lang-файла
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.combatmenu.open",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.combatmenu"
        ));

        // Обработка нажатий в конце каждого клиентского тика
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.wasPressed()) {
                // Открываем меню только если сейчас нет другого экрана
                if (client.currentScreen == null) {
                    client.setScreen(new CombatMenuScreen());
                }
            }
        });
    }
}
