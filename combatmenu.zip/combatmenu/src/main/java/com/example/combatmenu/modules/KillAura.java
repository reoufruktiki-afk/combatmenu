package com.example.combatmenu.modules;

public class KillAura {
    // Состояние модуля (включён / выключен)
    public static boolean enabled = false;
}
