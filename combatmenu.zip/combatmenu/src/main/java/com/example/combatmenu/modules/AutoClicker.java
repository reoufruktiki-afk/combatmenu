package com.example.combatmenu.modules;

public class AutoClicker {
    // Состояние модуля (включён / выключен)
    public static boolean enabled = false;
}
