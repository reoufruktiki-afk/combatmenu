package com.example.combatmenu;

import com.example.combatmenu.modules.AutoClicker;
import com.example.combatmenu.modules.Clock;
import com.example.combatmenu.modules.KillAura;
import com.example.combatmenu.modules.Reach;
import com.example.combatmenu.modules.Velocity;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.function.BooleanSupplier;

public class CombatMenuScreen extends Screen {

    // Размеры и отступы кнопок
    private static final int BUTTON_WIDTH = 150;
    private static final int BUTTON_HEIGHT = 20;
    private static final int BUTTON_SPACING = 4;

    public CombatMenuScreen() {
        super(Text.literal("Combat Menu"));
    }

    @Override
    protected void init() {
        // Всего 5 кнопок-переключателей + кнопка закрытия
        int count = 6;
        int totalHeight = count * BUTTON_HEIGHT + (count - 1) * BUTTON_SPACING;
        int x = this.width / 2 - BUTTON_WIDTH / 2;
        int y = this.height / 2 - totalHeight / 2 + 10; // небольшой сдвиг вниз под заголовок

        // Кнопки модулей, каждая в своей строке
        addToggle("KillAura", () -> KillAura.enabled, () -> KillAura.enabled = !KillAura.enabled, x, y);
        y += BUTTON_HEIGHT + BUTTON_SPACING;

        addToggle("AutoClicker", () -> AutoClicker.enabled, () -> AutoClicker.enabled = !AutoClicker.enabled, x, y);
        y += BUTTON_HEIGHT + BUTTON_SPACING;

        addToggle("Reach", () -> Reach.enabled, () -> Reach.enabled = !Reach.enabled, x, y);
        y += BUTTON_HEIGHT + BUTTON_SPACING;

        addToggle("Velocity", () -> Velocity.enabled, () -> Velocity.enabled = !Velocity.enabled, x, y);
        y += BUTTON_HEIGHT + BUTTON_SPACING;

        addToggle("Clock", () -> Clock.enabled, () -> Clock.enabled = !Clock.enabled, x, y);
        y += BUTTON_HEIGHT + BUTTON_SPACING;

        // Кнопка закрытия меню
        this.addDrawableChild(
                ButtonWidget.builder(Text.literal("Close"), btn -> this.close())
                        .dimensions(x, y, BUTTON_WIDTH, BUTTON_HEIGHT)
                        .build()
        );
    }

    /**
     * Создаёт кнопку-переключатель с текстом "Имя: ON/OFF".
     * При клике состояние меняется, а текст обновляется через setMessage.
     */
    private void addToggle(String name, BooleanSupplier getter, Runnable toggler, int x, int y) {
        ButtonWidget btn = ButtonWidget.builder(label(name, getter.getAsBoolean()), button -> {
                    // Меняем состояние модуля
                    toggler.run();
                    // Обновляем текст кнопки
                    button.setMessage(label(name, getter.getAsBoolean()));
                })
                .dimensions(x, y, BUTTON_WIDTH, BUTTON_HEIGHT)
                .build();
        this.addDrawableChild(btn);
    }

    // Формирует текст кнопки
    private static Text label(String name, boolean enabled) {
        return Text.literal(name + ": " + (enabled ? "ON" : "OFF"));
    }

    // Рисуем собственный полупрозрачный тёмный фон (без размытия ванильного фона)
    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, this.width, this.height, 0xAA000000);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // super.render рисует фон (наш override) и все виджеты
        super.render(context, mouseX, mouseY, delta);

        // Заголовок по центру сверху
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 20, 0xFFFFFF);

        // Часы в правом верхнем углу, обновляются каждый кадр
        if (Clock.enabled) {
            String time = Clock.getTime();
            int textWidth = this.textRenderer.getWidth(time);
            context.drawTextWithShadow(this.textRenderer, time, this.width - textWidth - 6, 6, 0xFFFFFF);
        }
    }

    // Игра не ставится на паузу, пока меню открыто
    @Override
    public boolean shouldPause() {
        return false;
    }
}
