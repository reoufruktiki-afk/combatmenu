package com.example.combatmenu.modules;

public class Reach {
    // Состояние модуля (включён / выключен)
    public static boolean enabled = false;
}
